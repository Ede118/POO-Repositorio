
#ifndef FUNCION_H
#define FUNCION_H

#include string


namespace TP1Act4 {


/**
  * class funcion
  * 
  */

class funcion
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  funcion();

  /**
   * Empty Destructor
   */
  virtual ~funcion();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  


  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //

};
} // end of package namespace

#endif // FUNCION_H
