
#ifndef APLICACIÓN_101_H
#define APLICACIÓN_101_H

#include string


namespace TP1Act4 {


/**
  * class Aplicación_101
  * 
  */

class Aplicación_101
{
public:
  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   */
  virtual void Input_datos() = 0;


  /**
   */
  virtual void Output_datos() = 0;


  /**
   */
  virtual void Ofrecer_Menu() = 0;


  /**
   */
  virtual void Graficar() = 0;

protected:
  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //

};
} // end of package namespace

#endif // APLICACIÓN_101_H
