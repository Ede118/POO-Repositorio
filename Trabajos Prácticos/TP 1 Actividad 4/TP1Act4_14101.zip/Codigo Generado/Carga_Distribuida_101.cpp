#include "Carga_Distribuida_101.h"

// Constructors/Destructors
//  

Carga_Distribuida_101::Carga_Distribuida_101()
{
  initAttributes();
}

Carga_Distribuida_101::~Carga_Distribuida_101()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void Carga_Distribuida_101::initAttributes()
{
}

