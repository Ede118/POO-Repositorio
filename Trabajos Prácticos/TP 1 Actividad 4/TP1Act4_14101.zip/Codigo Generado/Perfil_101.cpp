#include "Perfil_101.h"

// Constructors/Destructors
//  

Perfil_101::Perfil_101()
{
  initAttributes();
}

Perfil_101::~Perfil_101()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void Perfil_101::initAttributes()
{
}

