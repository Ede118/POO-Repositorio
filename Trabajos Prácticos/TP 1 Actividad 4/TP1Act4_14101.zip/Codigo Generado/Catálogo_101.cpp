#include "Catálogo_101.h"

// Constructors/Destructors
//  

Catálogo_101::Catálogo_101()
{
  initAttributes();
}

Catálogo_101::~Catálogo_101()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void Catálogo_101::initAttributes()
{
}

