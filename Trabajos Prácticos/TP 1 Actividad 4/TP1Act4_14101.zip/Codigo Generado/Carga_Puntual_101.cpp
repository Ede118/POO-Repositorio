#include "Carga_Puntual_101.h"

// Constructors/Destructors
//  

Carga_Puntual_101::Carga_Puntual_101()
{
  initAttributes();
}

Carga_Puntual_101::~Carga_Puntual_101()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void Carga_Puntual_101::initAttributes()
{
}

