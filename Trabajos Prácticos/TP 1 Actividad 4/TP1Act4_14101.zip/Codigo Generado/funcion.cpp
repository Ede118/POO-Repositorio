#include "funcion.h"

// Constructors/Destructors
//  

funcion::funcion()
{
}

funcion::~funcion()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  


